from django.apps import AppConfig


class EditorConfig(AppConfig):
    name = 'editor'
