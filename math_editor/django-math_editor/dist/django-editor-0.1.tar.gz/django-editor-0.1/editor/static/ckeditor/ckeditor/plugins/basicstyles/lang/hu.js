﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'hu', {
	bold: 'Félkövér',
	italic: 'Dőlt',
	strike: 'Áthúzott',
	subscript: 'Alsó index',
	superscript: 'Felső index',
	underline: 'Aláhúzott'
} );
